<p>Greetings from Arab Fashion Week Protocol Team,</p>

<p style="margin: 0">
    Here is your ticket, attached in PDF, to attend the Arab Fashion Week x d3 for Womenswear FW22/23 from 24-28 March 2022 in d3.
</p>
<p style="margin: 0">Please note to arrive at least 30 mins ahead of time to enjoy your allocated seat. Late arrival might be denied access.
</p>
<p style="margin: 0"> See you at the shows.</p>

<p>    Arab Fashion Week - Protocol Team</p>
</p>



